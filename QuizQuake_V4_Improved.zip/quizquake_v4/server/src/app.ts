import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { z } from 'zod';
import swaggerUi from 'swagger-ui-express';
import { questionBank } from './questions.js';
import { calculatePercentile, estimateAbility, nextDifficulty, type Difficulty } from './engine.js';
import { createUser, findUser, listAttempts, saveAttempt } from './store.js';
import { authenticate, createToken, hashPassword, verifyPassword } from './auth.js';

export const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '20kb' }));
app.use((req, res, next) => {
 const started = Date.now();
 res.on('finish', () => console.log(JSON.stringify({ time: new Date().toISOString(), method: req.method, path: req.path, status: res.statusCode, durationMs: Date.now() - started })));
 next();
});
app.use('/api', rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60_000, limit: 20, standardHeaders: 'draft-7', legacyHeaders: false }));

const subjects = ['Computer Science', 'Mathematics', 'Science', 'General Knowledge'] as const;
const openApi = {
 openapi: '3.0.3', info: { title: 'QuizQuake API', version: '4.0.0', description: 'Authentication, adaptive quiz and attempt history API.' },
 servers: [{ url: 'http://localhost:4000' }],
 components: { securitySchemes: { bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } } },
 paths: {
  '/api/health': { get: { summary: 'Health check', responses: { '200': { description: 'API is healthy' } } } },
  '/api/auth/register': { post: { summary: 'Create a student account', responses: { '201': { description: 'Account created' }, '409': { description: 'Username already exists' } } } },
  '/api/auth/login': { post: { summary: 'Sign in', responses: { '200': { description: 'JWT session returned' }, '401': { description: 'Invalid credentials' } } } },
  '/api/questions': { get: { summary: 'Get questions without answer keys', parameters: [{ name: 'subject', in: 'query', required: true, schema: { type: 'string' } }, { name: 'difficulty', in: 'query', required: true, schema: { type: 'string', enum: ['Easy','Medium','Hard'] } }], responses: { '200': { description: 'Question list' } } } },
  '/api/attempts': { get: { summary: 'Get paginated signed-in user history', security: [{ bearerAuth: [] }], responses: { '200': { description: 'Paginated attempt history' } } }, post: { summary: 'Save a completed attempt', security: [{ bearerAuth: [] }], responses: { '201': { description: 'Attempt saved' } } } }
 }
};
app.get('/api/openapi.json', (_req, res) => res.json(openApi));
app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(openApi));
app.get('/api/health', (_req, res) => res.json({ status: 'ok', app: 'QuizQuake', version: '4.0.0' }));

const authSchema = z.object({ username: z.string().trim().min(3).max(24).regex(/^[a-zA-Z0-9_.-]+$/), password: z.string().min(8).max(72) });
app.post('/api/auth/register', (req, res) => {
 const parsed = authSchema.safeParse(req.body);
 if (!parsed.success) return res.status(400).json({ error: 'Username must be 3–24 letters/numbers and password at least 8 characters.' });
 try {
  const user = createUser(parsed.data.username, hashPassword(parsed.data.password));
  return res.status(201).json({ token: createToken(user), user: { id: user.id, username: user.username } });
 } catch (error) {
  if (String(error).includes('UNIQUE')) return res.status(409).json({ error: 'That username is already taken.' });
  throw error;
 }
});
app.post('/api/auth/login', (req, res) => {
 const parsed = authSchema.safeParse(req.body);
 if (!parsed.success) return res.status(400).json({ error: 'Enter a valid username and password.' });
 const user = findUser(parsed.data.username);
 if (!user || !verifyPassword(parsed.data.password, user.passwordHash)) return res.status(401).json({ error: 'Incorrect username or password.' });
 return res.json({ token: createToken(user), user: { id: user.id, username: user.username } });
});
app.get('/api/auth/me', authenticate, (req, res) => res.json({ user: req.user }));

app.get('/api/subjects', (_req, res) => res.json(subjects));
app.get('/api/questions', (req, res) => {
 const parsed = z.object({ subject: z.enum(subjects), difficulty: z.enum(['Easy', 'Medium', 'Hard']) }).safeParse(req.query);
 if (!parsed.success) return res.status(400).json({ error: 'Choose a valid subject and difficulty.' });
 const questions = questionBank.filter(q => q.subject === parsed.data.subject && q.difficulty === parsed.data.difficulty).map(({ answer: _answer, ...question }) => question);
 return res.json(questions);
});

const answerCheckSchema = z.object({ questionId: z.string().min(1).max(20), subject: z.enum(subjects), selectedOption: z.number().int().min(-1).max(3) });
app.post('/api/answer-check', (req, res) => {
 const parsed = answerCheckSchema.safeParse(req.body);
 if (!parsed.success) return res.status(400).json({ error: 'Invalid answer.' });
 const question = questionBank.find(q => q.id === parsed.data.questionId && q.subject === parsed.data.subject);
 if (!question) return res.status(404).json({ error: 'Question not found.' });
 return res.json({ correct: question.answer === parsed.data.selectedOption, correctOption: question.answer, explanation: question.explanation });
});

const submitSchema = z.object({ subject: z.enum(subjects), answers: z.array(z.object({ questionId: z.string().min(1).max(20), selectedOption: z.number().int().min(-1).max(3), timeTaken: z.number().int().min(0).max(3600) })).min(1).max(20) });
app.post('/api/attempts', authenticate, (req, res) => {
 const parsed = submitSchema.safeParse(req.body);
 if (!parsed.success) return res.status(400).json({ error: 'Please check the submitted answers.', details: parsed.error.flatten() });
 const { subject, answers } = parsed.data;
 const checked = answers.map(answer => {
  const question = questionBank.find(q => q.id === answer.questionId && q.subject === subject);
  if (!question) return null;
  return { ...answer, correct: question.answer === answer.selectedOption, correctOption: question.answer, explanation: question.explanation, prompt: question.prompt, difficulty: question.difficulty, subject: question.subject };
 });
 if (checked.some(item => item === null)) return res.status(400).json({ error: 'One or more question IDs are not valid for this subject.' });
 const validAnswers = checked as NonNullable<typeof checked[number]>[];
 const score = validAnswers.filter(item => item.correct).length;
 const percentile = calculatePercentile(Math.round(score / validAnswers.length * 100));
 const abilityEstimate = estimateAbility(validAnswers.map(answer => ({ correct: answer.correct, difficulty: answer.difficulty })));
 const attempt = saveAttempt({ playerName: req.user!.username, subject, score, total: validAnswers.length, percentile, answers: validAnswers }, req.user!.id);
 return res.status(201).json({ ...attempt, answers: validAnswers, abilityEstimate });
});
app.get('/api/attempts', authenticate, (req, res) => {
 const parsed = z.object({ page: z.coerce.number().int().min(1).default(1), pageSize: z.coerce.number().int().min(1).max(50).default(10) }).safeParse(req.query);
 if (!parsed.success) return res.status(400).json({ error: 'Page must be positive and pageSize must be between 1 and 50.' });
 return res.json(listAttempts(req.user!.id, parsed.data.page, parsed.data.pageSize));
});
app.post('/api/difficulty/next', (req, res) => {
 const parsed = z.object({ difficulty: z.enum(['Easy', 'Medium', 'Hard']), correct: z.boolean(), streak: z.number().int().min(0).max(1) }).safeParse(req.body);
 if (!parsed.success) return res.status(400).json({ error: 'Invalid difficulty update.' });
 return res.json(nextDifficulty(parsed.data.difficulty as Difficulty, parsed.data.correct, parsed.data.streak));
});
app.use((err: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
 console.error('Request failed:', err);
 res.status(500).json({ error: 'Something went wrong. Please try again.' });
});
