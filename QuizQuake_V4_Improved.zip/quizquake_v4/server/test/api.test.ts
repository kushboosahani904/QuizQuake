import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { app } from '../src/app.js';

describe('QuizQuake API v4', () => {
 it('reports that the API is running', async () => {
  const response = await request(app).get('/api/health');
  expect(response.status).toBe(200); expect(response.body.status).toBe('ok');
 });
 it('rejects an unknown quiz difficulty', async () => {
  expect((await request(app).get('/api/questions?subject=Science&difficulty=Expert')).status).toBe(400);
 });
 it('requires authentication before returning attempt history', async () => {
  expect((await request(app).get('/api/attempts')).status).toBe(401);
 });
 it('requires authentication before accepting an attempt', async () => {
  expect((await request(app).post('/api/attempts').send({ subject: 'Science', answers: [] })).status).toBe(401);
 });
 it('publishes OpenAPI documentation', async () => {
  const response = await request(app).get('/api/openapi.json');
  expect(response.status).toBe(200); expect(response.body.openapi).toBe('3.0.3');
 });
 it('registers a user and returns a signed session token', async () => {
  const username = `test_${Date.now()}`;
  const response = await request(app).post('/api/auth/register').send({ username, password: 'StrongPass123' });
  expect(response.status).toBe(201); expect(response.body.token).toBeTypeOf('string');
  const me = await request(app).get('/api/auth/me').set('Authorization', `Bearer ${response.body.token}`);
  expect(me.status).toBe(200); expect(me.body.user.username).toBe(username);
 });
});
