import { describe, expect, it } from "vitest";
import { calculatePercentile, nextDifficulty } from "../src/engine.js";

describe("adaptive difficulty", () => {
  it("keeps the same level after the first correct answer", () => {
    expect(nextDifficulty("Easy", true, 0)).toEqual({ difficulty: "Easy", streak: 1 });
  });
  it("moves up after two consecutive correct answers", () => {
    expect(nextDifficulty("Easy", true, 1)).toEqual({ difficulty: "Medium", streak: 0 });
  });
  it("moves down after a wrong answer and resets the streak", () => {
    expect(nextDifficulty("Hard", false, 1)).toEqual({ difficulty: "Medium", streak: 0 });
  });
  it("does not move above Hard or below Easy", () => {
    expect(nextDifficulty("Hard", true, 1).difficulty).toBe("Hard");
    expect(nextDifficulty("Easy", false, 0).difficulty).toBe("Easy");
  });
});

describe("cohort estimate", () => {
  it("returns a middle estimate for a score at the cohort mean", () => {
    expect(calculatePercentile(60)).toBe(50);
  });
  it("handles a zero standard deviation safely", () => {
    expect(calculatePercentile(70, 60, 0)).toBe(100);
  });
});

describe('item-response ability estimate', () => {
 it('estimates stronger ability for consistently correct answers', () => {
  const strong = estimateAbility(Array.from({ length: 8 }, (_, index) => ({ correct: true, difficulty: index % 2 ? 'Hard' as const : 'Medium' as const })));
  const weak = estimateAbility(Array.from({ length: 8 }, (_, index) => ({ correct: false, difficulty: index % 2 ? 'Hard' as const : 'Medium' as const })));
  expect(strong).toBeGreaterThan(weak);
 });
 it('returns zero for an empty response set', () => expect(estimateAbility([])).toBe(0));
});
