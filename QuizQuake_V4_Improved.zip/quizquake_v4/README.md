# QuizQuake – BrainStorm Arena (Version 4)

QuizQuake is a student learning project built with React, TypeScript, Express and SQLite. Version 4 focuses on the specific improvement points in the Attempt #3 evaluation: authentication, API documentation, frontend tests, transaction-safe persistence and paginated history.

## Features

- Four subjects with Easy, Medium and Hard question levels.
- 12-question adaptive rounds and a 30-second per-question timer.
- Server-side answer checking; question responses do not include the answer key.
- Result review with explanations, time taken, difficulty radar chart and a bounded 2PL-style ability estimate (illustrative, not calibrated on a real cohort).
- A visible **Critical Weak Area** notice when at least two questions at a difficulty level were attempted and accuracy is below 60%.
- Student registration and login with salted scrypt password hashes and signed 12-hour JWT bearer sessions.
- Attempt history is scoped to the authenticated account; one student cannot request another student's records by changing a name query parameter.
- Server-side history pagination (`page`, `pageSize`, maximum page size 50).
- SQLite WAL mode, a 5-second busy timeout, foreign-key enforcement, an index for history lookups and transaction-wrapped attempt inserts.
- Zod request validation, Helmet security headers, request-size limit, API rate limiting and structured request logs.
- OpenAPI specification at `/api/openapi.json` and Swagger UI at `/api/docs`.
- Server unit/API tests and frontend component tests (Vitest + React Testing Library).

## Requirements

- Node.js 20 or later
- npm 10 or later

## Run locally

1. Extract the ZIP and open the `quizquake_v4` folder in VS Code.
2. Run `npm install` from the project root.
3. Optionally copy `server/.env.example` to `server/.env` to customize API settings.
4. Run `npm run dev`.
5. Open `http://localhost:5173`. The API runs on `http://localhost:4000`.
6. Create an account on the home page, then choose a subject and start a quiz.

The SQLite database is created automatically in the server workspace. Do not commit `.env` or database files.

## API documentation

- Swagger UI: `http://localhost:4000/api/docs`
- OpenAPI JSON: `http://localhost:4000/api/openapi.json`
- Health check: `http://localhost:4000/api/health`

Protected routes require `Authorization: Bearer <token>`. Register or log in through `/api/auth/register` or `/api/auth/login` to receive a token.

## Tests and production build

From the project root:

```bash
npm test
npm run build
```

The server tests cover adaptive difficulty, percentile edge cases, authentication requirements, registration and OpenAPI output. Frontend tests cover the history empty state, result rendering and pagination callback.

## Security and deployment notes

- Set a strong random `JWT_SECRET` in the server environment file or deployment environment. The server refuses to start in production when it is missing.
- Set `CLIENT_ORIGIN` to the exact deployed frontend origin.
- Use HTTPS in deployment. The sample frontend stores the short-lived bearer token in browser local storage for simplicity; a production deployment should consider secure, HttpOnly, SameSite cookies and a CSRF strategy.
- This is an educational prototype, not a production examination or student-information system. Add account recovery, email verification, audit retention and operational monitoring before real institutional use.
- Existing V3 attempt rows are retained in the same SQLite file but have no account owner; V4 history displays only attempts created under the signed-in account.

## Main folders

- `client/src/App.tsx` – authentication, quiz flow, results and weak-area notice
- `client/src/History.tsx` – paginated attempt history
- `client/src/__tests__/History.test.tsx` – frontend component tests
- `server/src/auth.ts` – password hashing and JWT verification
- `server/src/engine.ts` – adaptive difficulty and percentile estimate
- `server/src/store.ts` – SQLite schema, transactions and pagination
- `server/src/app.ts` – API routes, validation and OpenAPI documentation
- `server/test/` – backend tests

## Before submitting

Run `npm install`, `npm test` and `npm run build` on your computer. Create a new account, complete a quiz, sign out and sign back in, confirm the attempt is still in history, test the Next/Previous history buttons, and open Swagger UI. Capture screenshots from your actual running application. Do not state that tests passed unless the commands complete successfully on your machine.
