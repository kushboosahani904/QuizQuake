import { describe, expect, it, vi } from 'vitest';
import { fireEvent, render, screen } from '@testing-library/react';
import History from '../History';

vi.mock('react-chartjs-2', () => ({ Bar: () => <div data-testid="score-chart" /> }));

describe('History', () => {
 const pagination = { page: 1, pageSize: 10, total: 11, totalPages: 2 };
 it('shows an empty state when there are no attempts', () => {
  render(<History playerName="Varun" attempts={[]} pagination={{ ...pagination, total: 0, totalPages: 0 }} onPageChange={vi.fn()} />);
  expect(screen.getByText(/No attempts found yet/i)).toBeInTheDocument();
 });
 it('renders attempt results and calls the next-page handler', () => {
  const onPageChange = vi.fn();
  render(<History playerName="Varun" pagination={pagination} onPageChange={onPageChange} attempts={[{ id: 'a1', subject: 'Science', score: 8, total: 10, createdAt: '2025-01-01T10:00:00Z' }]} />);
  expect(screen.getByText('8/10')).toBeInTheDocument();
  expect(screen.getByTestId('score-chart')).toBeInTheDocument();
  fireEvent.click(screen.getByRole('button', { name: /Next/i }));
  expect(onPageChange).toHaveBeenCalledWith(2);
 });
});
