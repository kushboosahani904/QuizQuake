import { useEffect, useMemo, useState } from "react";
import { Radar } from "react-chartjs-2";
import History from "./History";
import { Chart as ChartJS, RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend } from "chart.js";
ChartJS.register(RadialLinearScale, PointElement, LineElement, Filler, Tooltip, Legend);

const API = import.meta.env.VITE_API_URL || "http://localhost:4000/api";
let authToken = localStorage.getItem("quizquake_token") || "";
const subjects = ["Computer Science", "Mathematics", "Science", "General Knowledge"];
type Difficulty = "Easy" | "Medium" | "Hard";
type Question = { id: string; subject: string; difficulty: Difficulty; prompt: string; options: string[] };
type Answer = { questionId: string; selectedOption: number; timeTaken: number };
type Review = Answer & { correct: boolean; correctOption: number; explanation: string; prompt: string; difficulty: Difficulty; subject: string };
type Attempt = { id: string; playerName: string; subject: string; score: number; total: number; percentile: number; abilityEstimate?: number; answers: Review[]; createdAt: string };

async function api<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${API}${path}`, { ...options, headers: { "Content-Type": "application/json", ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}), ...options?.headers } });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Request failed. Please try again.");
  return data as T;
}

export default function App() {
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [authMode, setAuthMode] = useState<"login" | "register">("register");
  const [authenticated, setAuthenticated] = useState(Boolean(authToken));
  const [historyMeta, setHistoryMeta] = useState({ page: 1, pageSize: 10, total: 0, totalPages: 0 });
  const [subject, setSubject] = useState(subjects[0]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [questionPool, setQuestionPool] = useState<Question[]>([]);
  const [usedIds, setUsedIds] = useState<string[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [difficulty, setDifficulty] = useState<Difficulty>("Easy");
  const [streak, setStreak] = useState(0);
  const [seconds, setSeconds] = useState(30);
  const [startedAt, setStartedAt] = useState(Date.now());
  const [attempt, setAttempt] = useState<Attempt | null>(null);
  const [history, setHistory] = useState<Attempt[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [page, setPage] = useState<"home" | "quiz" | "result" | "history">("home");
  const current = questions[index];

  useEffect(() => {
    if (!authToken) return;
    void api<{user:{username:string}}>("/auth/me").then(result => {
      setName(result.user.username); setAuthenticated(true);
    }).catch(() => {
      authToken = ""; localStorage.removeItem("quizquake_token"); setAuthenticated(false);
    });
  }, []);

  useEffect(() => {
    if (page !== "quiz") return;
    const timer = window.setInterval(() => setSeconds(value => value > 0 ? value - 1 : 0), 1000);
    return () => window.clearInterval(timer);
  }, [page, index]);

  useEffect(() => {
    if (page === "quiz" && seconds === 0 && selected !== null) void submitAnswer();
    if (page === "quiz" && seconds === 0 && selected === null) void submitAnswer(-1);
  }, [seconds]);

  const progress = useMemo(() => (index / 12) * 100, [index]);

  async function authenticateUser() {
    setError(""); setBusy(true);
    try {
      const result = await api<{token:string; user:{username:string}}>(`/auth/${authMode}`, { method: "POST", body: JSON.stringify({ username, password }) });
      authToken = result.token; localStorage.setItem("quizquake_token", result.token);
      setName(result.user.username); setAuthenticated(true); setPassword("");
    } catch (e) { setError(e instanceof Error ? e.message : "Could not sign in."); }
    finally { setBusy(false); }
  }

  function signOut() {
    authToken = ""; localStorage.removeItem("quizquake_token"); setAuthenticated(false);
    setName(""); setHistory([]); setPage("home");
  }

  async function startQuiz() {
    setError("");
    if (!authenticated) { setError("Please create an account or sign in first."); return; }
    setBusy(true);
    try {
      const levels = await Promise.all((["Easy", "Medium", "Hard"] as Difficulty[]).map(level => api<Question[]>(`/questions?subject=${encodeURIComponent(subject)}&difficulty=${level}`)));
      const pool = levels.flat();
      const first = pool.filter(question => question.difficulty === "Easy");
      const openingQuestion = first[Math.floor(Math.random() * first.length)];
      setQuestionPool(pool); setQuestions([openingQuestion]); setUsedIds([openingQuestion.id]);
      setAnswers([]); setIndex(0); setSelected(null); setDifficulty("Easy"); setStreak(0);
      setSeconds(30); setStartedAt(Date.now()); setAttempt(null); setPage("quiz");
    } catch (e) { setError(e instanceof Error ? e.message : "Could not load questions."); }
    finally { setBusy(false); }
  }

  async function submitAnswer(forcedSelection?: number) {
    if (!current || busy) return;
    const choice = forcedSelection ?? selected;
    if (choice === null) return;
    setBusy(true);
    const elapsed = Math.max(0, Math.round((Date.now() - startedAt) / 1000));
    const nextAnswers = [...answers, { questionId: current.id, selectedOption: choice, timeTaken: elapsed }];
    try {
      const checked = await api<{correct:boolean}>("/answer-check", { method: "POST", body: JSON.stringify({ questionId: current.id, subject, selectedOption: choice }) });
      let nextLevel: Difficulty = difficulty;
      let nextStreak = streak;
      if (!checked.correct) {
        const levels: Difficulty[] = ["Easy", "Medium", "Hard"];
        nextLevel = levels[Math.max(0, levels.indexOf(difficulty) - 1)];
        nextStreak = 0;
      } else if (streak + 1 >= 2) {
        const levels: Difficulty[] = ["Easy", "Medium", "Hard"];
        nextLevel = levels[Math.min(2, levels.indexOf(difficulty) + 1)];
        nextStreak = 0;
      } else {
        nextStreak = streak + 1;
      }
      setAnswers(nextAnswers); setSelected(null); setSeconds(30); setStartedAt(Date.now());
      setDifficulty(nextLevel); setStreak(nextStreak);
      if (nextAnswers.length >= 12) {
        const result = await api<Attempt>("/attempts", { method: "POST", body: JSON.stringify({ subject, answers: nextAnswers }) });
        setAttempt(result); setPage("result");
      } else {
        const available = questionPool.filter(question => question.difficulty === nextLevel && !usedIds.includes(question.id));
        const fallback = questionPool.filter(question => !usedIds.includes(question.id));
        const choices = available.length ? available : fallback;
        if (!choices.length) throw new Error("There are no unused questions left. Please start a new round.");
        const nextQuestion = choices[Math.floor(Math.random() * choices.length)];
        setQuestions(items => [...items, nextQuestion]); setUsedIds(items => [...items, nextQuestion.id]);
        setIndex(value => value + 1);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not submit this answer.");
    } finally { setBusy(false); }
  }

  async function loadHistory(pageNumber = 1) {
    setError("");
    if (!authenticated) { setError("Please sign in to view your private history."); return; }
    try {
      const result = await api<{items:Attempt[]; pagination:typeof historyMeta}>(`/attempts?page=${pageNumber}&pageSize=10`);
      setHistory(result.items); setHistoryMeta(result.pagination); setPage("history");
    } catch (e) { setError(e instanceof Error ? e.message : "Could not load history."); }
  }

  async function goHome() { setPage("home"); setError(""); }

  return <main className="shell">
    <header className="topbar"><div className="brand"><span className="brand-mark">Q</span><div><strong>QuizQuake</strong><small>BrainStorm Arena</small></div></div><nav><button className="nav-button" onClick={goHome}>Home</button>{authenticated && <><button className="nav-button" onClick={() => void loadHistory(1)}>Attempt history</button><button className="nav-button" onClick={signOut}>Sign out</button></>}</nav></header>
    {error && <div className="alert" role="alert">{error}</div>}
    {page === "home" && <section className="hero"><div className="hero-copy"><span className="eyebrow">LEARN • PRACTISE • IMPROVE</span><h1>Make every answer<br/><em>count.</em></h1><p>A quiz arena that adjusts the challenge as you play. Take a short round, check your explanations and see where you can improve.</p><div className="start-card">{!authenticated ? <><label>Username<input value={username} onChange={e => setUsername(e.target.value)} placeholder="Choose a username" maxLength={24}/></label><label>Password<input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 8 characters" maxLength={72}/></label><button className="primary" onClick={() => void authenticateUser()} disabled={busy}>{busy ? "Please wait…" : authMode === "register" ? "Create account" : "Sign in"}</button><button className="nav-button" onClick={() => setAuthMode(authMode === "register" ? "login" : "register")}>{authMode === "register" ? "Already registered? Sign in" : "New here? Create an account"}</button></> : <><p>Signed in as <strong>{name}</strong></p><label>Choose a subject<select value={subject} onChange={e => setSubject(e.target.value)}>{subjects.map(item => <option key={item}>{item}</option>)}</select></label><button className="primary" onClick={startQuiz} disabled={busy}>{busy ? "Loading questions…" : "Start a quiz →"}</button></>}</div></div><div className="hero-art"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="quiz-card"><span className="card-tag">TODAY'S CHALLENGE</span><div className="big-question">?</div><h3>Think it through.</h3><p>One question at a time. Build your streak.</p><div className="mini-bars"><i/><i/><i/><i/><i/></div></div><span className="float-chip chip-a">✦ Adaptive levels</span><span className="float-chip chip-b">12 questions</span></div></section>}
    {page === "quiz" && current && <section className="quiz-wrap"><div className="quiz-head"><div><span className="eyebrow">{subject.toUpperCase()}</span><h2>Question {index + 1} <small>of {questions.length}</small></h2></div><div className="timer">◷ 00:{String(seconds).padStart(2,"0")}</div></div><div className="progress"><span style={{width:`${progress}%`}}/></div><div className="quiz-meta"><span className={`level ${current.difficulty.toLowerCase()}`}>{current.difficulty} level</span><span>{Math.round(progress)}% completed</span></div><article className="question-card"><h2>{current.prompt}</h2><div className="options">{current.options.map((option, i) => <button key={option} className={`option ${selected === i ? "chosen" : ""}`} onClick={() => setSelected(i)}><span>{String.fromCharCode(65+i)}</span>{option}</button>)}</div><div className="question-actions"><small>Your answer is saved when you continue.</small><button className="primary" disabled={selected === null || busy} onClick={() => void submitAnswer()}>{index === questions.length - 1 ? "Finish quiz" : "Submit & continue"} →</button></div></article></section>}
    {page === "result" && attempt && <section className="result-wrap"><span className="eyebrow">ROUND COMPLETE</span><h1>Good work, {attempt.playerName}.</h1><div className="result-grid"><div className="score-card"><small>YOUR SCORE</small><strong>{attempt.score}<i>/{attempt.total}</i></strong><p>{Math.round(attempt.score / attempt.total * 100)}% correct</p></div><div className="score-card"><small>ESTIMATED COHORT PERCENTILE</small><strong>{attempt.percentile}<i>th</i></strong><p>A practice estimate, not a live class ranking.</p></div><div className="score-card"><small>ESTIMATED ABILITY (2PL MODEL)</small><strong>{attempt.abilityEstimate ?? 0}</strong><p>Experimental practice estimate, not a validated exam score.</p></div></div><div className="radar-card"><div><h2>Difficulty balance</h2><p>Accuracy across the question levels in this round.</p></div>{["Easy","Medium","Hard"].map(level => { const group = attempt.answers.filter(answer => answer.difficulty === level); const accuracy = group.length ? group.filter(answer => answer.correct).length / group.length : 1; return group.length >= 2 && accuracy < 0.6 ? <div className="alert" key={level}>Critical Weak Area: {level} questions ({Math.round(accuracy * 100)}% accuracy). Practise this level next.</div> : null; })}<Radar data={{labels:["Easy","Medium","Hard"],datasets:[{label:"Accuracy (%)",data:["Easy","Medium","Hard"].map(level=>{const group=attempt.answers.filter(answer=>answer.difficulty===level);return group.length?Math.round(group.filter(answer=>answer.correct).length/group.length*100):0;}),backgroundColor:"rgba(154,137,255,.22)",borderColor:"#a99cff",pointBackgroundColor:"#c2b8ff",borderWidth:2}]}} options={{responsive:true,scales:{r:{beginAtZero:true,max:100,ticks:{stepSize:25,color:"#aab1c2",backdropColor:"transparent"},grid:{color:"#ffffff20"},angleLines:{color:"#ffffff20"},pointLabels:{color:"#d8d9e5"}}},plugins:{legend:{labels:{color:"#d8d9e5"}}}}}/></div><h2>Answer review</h2><div className="review-list">{attempt.answers.map((answer, i) => <article className="review-item" key={`${answer.questionId}-${i}`}><div className="review-title"><b>{i+1}. {answer.prompt}</b><span className={answer.correct ? "correct" : "wrong"}>{answer.correct ? "Correct" : "Review"}</span></div><p>Correct answer: <strong>{["A","B","C","D"][answer.correctOption]}</strong></p><p>{answer.explanation}</p><small>Time taken: {answer.timeTaken}s</small></article>)}</div><button className="primary" onClick={goHome}>Back to home</button></section>}
    {page === "history" && <History playerName={name} attempts={history} pagination={historyMeta} onPageChange={(next) => void loadHistory(next)} /> }
    <footer><span>QuizQuake · BrainStorm Arena</span><span>Built for learning, one round at a time.</span></footer>
  </main>;
}
