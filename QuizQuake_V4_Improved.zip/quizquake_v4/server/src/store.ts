import Database from 'better-sqlite3';
import { randomUUID } from 'node:crypto';

const db = new Database(process.env.DB_FILE || 'quizquake.sqlite', { timeout: 5000 });
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 5000');
db.pragma('foreign_keys = ON');
db.exec(`CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
 password_hash TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attempts (
 id TEXT PRIMARY KEY, user_id TEXT REFERENCES users(id) ON DELETE CASCADE,
 player_name TEXT NOT NULL, subject TEXT NOT NULL, score INTEGER NOT NULL,
 total INTEGER NOT NULL, percentile INTEGER NOT NULL, answers_json TEXT NOT NULL,
 created_at TEXT NOT NULL
);`);
const columns = db.pragma('table_info(attempts)') as Array<{name:string}>;
if (!columns.some(column => column.name === 'user_id')) db.exec('ALTER TABLE attempts ADD COLUMN user_id TEXT REFERENCES users(id)');
db.exec('CREATE INDEX IF NOT EXISTS idx_attempts_user_created ON attempts(user_id, created_at DESC)');

export type User = { id: string; username: string; passwordHash: string };
export type SavedAttempt = { id: string; playerName: string; subject: string; score: number; total: number; percentile: number; answers: unknown[]; createdAt: string };
export function createUser(username: string, passwordHash: string): User {
 const user = { id: randomUUID(), username, passwordHash };
 db.prepare('INSERT INTO users(id, username, password_hash, created_at) VALUES (?, ?, ?, ?)').run(user.id, user.username, user.passwordHash, new Date().toISOString());
 return user;
}
export function findUser(username: string): User | undefined {
 const row = db.prepare('SELECT id, username, password_hash FROM users WHERE username = ? COLLATE NOCASE').get(username) as any;
 return row ? { id: row.id, username: row.username, passwordHash: row.password_hash } : undefined;
}
export function saveAttempt(input: Omit<SavedAttempt, 'id'|'createdAt'>, userId: string): SavedAttempt {
 const attempt: SavedAttempt = { ...input, id: randomUUID(), createdAt: new Date().toISOString() };
 const insert = db.prepare(`INSERT INTO attempts(id,user_id,player_name,subject,score,total,percentile,answers_json,created_at)
 VALUES(@id,@userId,@playerName,@subject,@score,@total,@percentile,@answers,@createdAt)`);
 const transaction = db.transaction(() => insert.run({ ...attempt, userId, answers: JSON.stringify(attempt.answers) }));
 transaction();
 return attempt;
}
export function listAttempts(userId: string, page: number, pageSize: number) {
 const count = (db.prepare('SELECT COUNT(*) AS total FROM attempts WHERE user_id = ?').get(userId) as {total:number}).total;
 const rows = db.prepare('SELECT * FROM attempts WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?').all(userId, pageSize, (page - 1) * pageSize) as any[];
 const items: SavedAttempt[] = rows.map(row => ({ id: row.id, playerName: row.player_name, subject: row.subject, score: row.score, total: row.total, percentile: row.percentile, answers: JSON.parse(row.answers_json), createdAt: row.created_at }));
 return { items, pagination: { page, pageSize, total: count, totalPages: Math.ceil(count / pageSize) } };
}
