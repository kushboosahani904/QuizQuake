# QuizQuake V4 – Manual Testing Checklist

## Setup
- [ ] Use Node.js 20+ and npm 10+.
- [ ] Run `npm install`.
- [ ] Copy `.env.example` to `.env` and set a unique `JWT_SECRET` for deployment.
- [ ] Run `npm test` and `npm run build`; save the terminal output.

## Authentication and privacy
- [ ] Register a new username with a password of at least 8 characters.
- [ ] Confirm a duplicate username is rejected.
- [ ] Sign out and sign in with the same account.
- [ ] Try an incorrect password and confirm access is denied.
- [ ] Confirm history is not available without a valid token.
- [ ] Confirm a different account cannot see the first account's history.

## Quiz behaviour
- [ ] Test all four subjects.
- [ ] Confirm the first question is Easy.
- [ ] Confirm two correct answers in a row raise the next difficulty by one level.
- [ ] Confirm a wrong answer lowers the next difficulty by one level.
- [ ] Confirm the timer submits an unanswered question when it reaches zero.
- [ ] Complete a 12-question round and review explanations and the radar chart.
- [ ] Confirm the Critical Weak Area notice appears when the rule is met.

## History, database and docs
- [ ] Complete more than 10 attempts and check Next/Previous pagination.
- [ ] Restart the server and confirm saved attempts remain.
- [ ] Open `http://localhost:4000/api/docs` and try the documented endpoints.
- [ ] Open `http://localhost:4000/api/openapi.json` and confirm the OpenAPI document loads.
