export type Difficulty = "Easy" | "Medium" | "Hard";

// Two correct answers in a row move the learner up one level.
// A wrong answer moves the next question down one level.
export function nextDifficulty(current: Difficulty, correct: boolean, streak: number): {
  difficulty: Difficulty;
  streak: number;
} {
  const levels: Difficulty[] = ["Easy", "Medium", "Hard"];
  if (!correct) {
    return { difficulty: levels[Math.max(0, levels.indexOf(current) - 1)], streak: 0 };
  }

  const newStreak = streak + 1;
  if (newStreak >= 2) {
    return { difficulty: levels[Math.min(2, levels.indexOf(current) + 1)], streak: 0 };
  }
  return { difficulty: current, streak: newStreak };
}

export function calculatePercentile(score: number, cohortMean = 60, cohortStdDev = 15): number {
  if (cohortStdDev <= 0) return score >= cohortMean ? 100 : 0;
  // Logistic approximation is stable and easy to explain in a student project.
  const z = (score - cohortMean) / cohortStdDev;
  return Math.round((1 / (1 + Math.exp(-1.702 * z))) * 100);
}

export function pickNextDifficulty(current: Difficulty, correct: boolean, streak: number) {
  return nextDifficulty(current, correct, streak);
}

/**
 * Small 2PL-style ability estimate for a completed practice round. Difficulty
 * locations are illustrative (Easy=-1, Medium=0, Hard=1), not calibrated
 * against a real student cohort. Newton-Raphson is bounded for stability.
 */
export function estimateAbility(responses: Array<{ correct: boolean; difficulty: Difficulty }>): number {
  if (!responses.length) return 0;
  const locations: Record<Difficulty, number> = { Easy: -1, Medium: 0, Hard: 1 };
  const discrimination = 1.15;
  let theta = 0;
  for (let iteration = 0; iteration < 12; iteration += 1) {
    let gradient = 0;
    let information = 0;
    for (const response of responses) {
      const probability = 1 / (1 + Math.exp(-discrimination * (theta - locations[response.difficulty])));
      gradient += discrimination * ((response.correct ? 1 : 0) - probability);
      information += discrimination * discrimination * probability * (1 - probability);
    }
    if (information < 1e-8) break;
    const step = gradient / information;
    theta = Math.max(-4, Math.min(4, theta + step));
    if (Math.abs(step) < 1e-4) break;
  }
  return Math.round(theta * 100) / 100;
}
