import { createHmac, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';
import type { Request, Response, NextFunction } from 'express';

if (process.env.NODE_ENV === 'production' && !process.env.JWT_SECRET) throw new Error('JWT_SECRET must be set in production.');
const secret = process.env.JWT_SECRET || 'local-development-secret-change-before-deployment';
const encode = (value: unknown) => Buffer.from(JSON.stringify(value)).toString('base64url');
export type AuthUser = { id: string; username: string };
declare global { namespace Express { interface Request { user?: AuthUser } } }

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  return `${salt}:${scryptSync(password, salt, 64).toString('hex')}`;
}
export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':');
  if (!salt || !hash) return false;
  const expected = Buffer.from(hash, 'hex');
  const actual = scryptSync(password, salt, 64);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
export function createToken(user: AuthUser): string {
  const header = encode({ alg: 'HS256', typ: 'JWT' });
  const payload = encode({ sub: user.id, username: user.username, exp: Math.floor(Date.now() / 1000) + 60 * 60 * 12 });
  const input = `${header}.${payload}`;
  return `${input}.${createHmac('sha256', secret).update(input).digest('base64url')}`;
}
export function authenticate(req: Request, res: Response, next: NextFunction) {
  const token = req.header('authorization')?.replace(/^Bearer\s+/i, '');
  if (!token) return res.status(401).json({ error: 'Please sign in to continue.' });
  try {
    const [header, payload, signature] = token.split('.');
    if (!header || !payload || !signature) throw new Error('Malformed token');
    const input = `${header}.${payload}`;
    const expected = createHmac('sha256', secret).update(input).digest();
    const actual = Buffer.from(signature, 'base64url');
    if (expected.length !== actual.length || !timingSafeEqual(expected, actual)) throw new Error('Invalid signature');
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString()) as { sub: string; username: string; exp: number };
    if (!data.sub || !data.username || data.exp < Date.now() / 1000) throw new Error('Expired token');
    req.user = { id: data.sub, username: data.username };
    next();
  } catch { return res.status(401).json({ error: 'Your session is invalid or expired. Please sign in again.' }); }
}
